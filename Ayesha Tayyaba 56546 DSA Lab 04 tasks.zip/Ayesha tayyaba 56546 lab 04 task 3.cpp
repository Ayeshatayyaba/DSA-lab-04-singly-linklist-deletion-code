#include<iostream>
using namespace std;
 struct Node{
 	int data;
 	Node*next;
 };
 //create a new node
 Node* createNode(int data){
 Node* newNode=new Node();
 newNode->data=data;
 newNode->next=NULL;
}
//function to display the linklist
void displayList(Node*head){
Node*temp=head;
while(temp){
	cout<<temp->data<<"->";
	temp=temp->next;
}
cout<<"Null"<<endl;
}//function to delete a node from a specified position
void deleteFromPosition(Node*&head,int position){
	Node*temp=head;
	for(int i=1;i<position-1;i++){
		temp=temp->next;
	}
	Node* nodetoDelete=temp->next;
	temp->next=nodetoDelete->next;
	delete nodetoDelete;
	cout<<"Node deleted from the position"<<position<<"."<<endl;
}
int main() {
	//creating linklist
	Node* head=createNode(10);
	head->next=createNode(20);
	head->next->next=createNode(30);
	head->next->next->next=createNode(40);
	cout<<"Original List";
	displayList(head);//Deleting from a specific position
	deleteFromPosition(head,2);
	displayList(head);
	return 0;
	
	}
