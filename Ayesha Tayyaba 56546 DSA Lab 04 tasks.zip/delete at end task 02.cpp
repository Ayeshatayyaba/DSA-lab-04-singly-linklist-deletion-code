#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

// Function to delete the last node
void deleteFromEnd(Node*& head) {
    if (head == NULL) { // Check if the list is empty
        cout << "List is empty!" << endl;
        return;
    }
    if (head->next == NULL) { // If only one node is present
        delete head;
        head = NULL;
        return;
    }

    Node* temp = head;
    while (temp->next->next != NULL) { // Traverse to second last node
        temp = temp->next;
    }
    delete temp->next; // Delete last node
    temp->next = NULL; // Update second last node's next to NULL
}

// Function to insert a node at the end
void insert(Node*& head, int value) {
    Node* newNode = new Node;
    newNode->data = value;
    newNode->next = NULL;

    if (head == NULL) {
        head = newNode;
        return;
    }
    Node* temp = head;
    while (temp->next != NULL)
        temp = temp->next;
    temp->next = newNode;
}

// Function to display the linked list
void display(Node* head) {
    if (head == NULL) {
        cout << "List is empty!" << endl;
        return;
    }
    Node* temp = head;
    while (temp != NULL) {
        cout << temp->data << " -> ";
        temp = temp->next;
    }
    cout << "NULL" << endl;
}

int main() {
    Node* head = NULL;

    // Insert some nodes
    insert(head, 10);
    insert(head, 20);
    insert(head, 30);

    cout << "Original List: ";
    display(head);

    // Delete last node
    deleteFromEnd(head);

    cout << "After Deletion: ";
    display(head);

    return 0;
}

